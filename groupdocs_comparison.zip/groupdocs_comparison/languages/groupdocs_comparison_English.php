<?php
define("GDCLAN_01", "Lets you embed compared document from your web page using the GroupDocs Signature (no Flash or PDF browser plug-ins required).");
define("GDCLAN_02", "Settings");
define("GDCLAN_03", "Installation Successful...");
define("GDCLAN_04", "Upgrade successful...");
define("GDCLAN_05", "Save Changes");
define("GDCLAN_06", "Changes were saved successfully.");
define("GDCLAN_07", "Error: please fill all inputs!");
?>